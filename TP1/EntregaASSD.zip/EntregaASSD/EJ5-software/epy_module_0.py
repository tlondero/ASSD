# this module will be imported in the into your flowgraph
import os

script_path = os.path.dirname(os.path.realpath(__file__))
os.chdir(script_path)