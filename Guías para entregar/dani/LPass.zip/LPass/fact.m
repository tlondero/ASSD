function p = fact(n)
%factorial de n
p=n;
while (n~=1)
  p=p*(n-1);
  n=n-1;
end



